package com.company.citibank;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.company.citibank.model.Account;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CitiBankControllerTests {

	MockMvc mockMvc;
	
	@Autowired
	CitiBankService bankService;
	
	@Autowired
	private WebApplicationContext context;
	
	@Before
	public void setup() {
		mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
	}
	
	@Test
	public void testCreateAccount() throws Exception {
		
		Account testAccount = new Account("101", "Adam Pike", 5000.00);
		bankService.createAccount(testAccount);
		
		mockMvc.perform(MockMvcRequestBuilders.get("/accountId/101").accept(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.accountId", Matchers.is("101")))
		.andExpect(jsonPath("$.accountName", Matchers.is("Adam Pike")))
		.andExpect(jsonPath("$.balance", Matchers.comparesEqualTo(5000.0)));
	}

	@Test
	public void testCreateAccountAndWithraw() throws Exception {
		
		Account testAccount = new Account("101", "Adam Pike", 5000.00);
		bankService.createAccount(testAccount);
		
		mockMvc.perform(MockMvcRequestBuilders.get("/accountId/101/withdraw/1000").accept(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$", Matchers.comparesEqualTo(4000.0)));
	}

	@Test
	public void testCreateAccountAndDeposit() throws Exception {
		
		Account testAccount = new Account("101", "Adam Pike", 5000.00);
		bankService.createAccount(testAccount);
		
		mockMvc.perform(MockMvcRequestBuilders.get("/accountId/101/deposit/2000").accept(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$", Matchers.comparesEqualTo(7000.0)));
	}

	@Test
	public void testCreateAccountsAndTransferBetween() throws Exception {
		
		Account testAccountFrom = new Account("101", "Adam Pike", 5000.00);
		bankService.createAccount(testAccountFrom);

		Account testAccountTo = new Account("102", "Helen Pike", 10000.00);
		bankService.createAccount(testAccountTo);

		mockMvc.perform(MockMvcRequestBuilders.get("/accountIdFrom/101/accountIdTo/102/transfer/2000"))
		.andExpect(status().isOk());
		
		mockMvc.perform(MockMvcRequestBuilders.get("/accountId/101").accept(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.accountId", Matchers.is("101")))
		.andExpect(jsonPath("$.accountName", Matchers.is("Adam Pike")))
		.andExpect(jsonPath("$.balance", Matchers.comparesEqualTo(3000.0)));

		mockMvc.perform(MockMvcRequestBuilders.get("/accountId/102").accept(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.accountId", Matchers.is("102")))
		.andExpect(jsonPath("$.accountName", Matchers.is("Helen Pike")))
		.andExpect(jsonPath("$.balance", Matchers.comparesEqualTo(12000.0)));
	}

}
