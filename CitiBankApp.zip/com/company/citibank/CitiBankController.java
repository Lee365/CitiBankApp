package com.company.citibank;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.company.citibank.model.Account;

@RestController
public class CitiBankController {

	@Autowired
	private CitiBankService bankService;
	
	@RequestMapping(method=RequestMethod.POST, value = "/account")
	public void createAccount(@RequestBody Account account) {
		bankService.createAccount(account);
	}
	
	@RequestMapping(value = "/accountId/{accountId}")
	public Optional<Account> getAccount(@PathVariable String accountId) {
		return bankService.getAccount(accountId);
	}

	@RequestMapping(value = "/accountId/{accountId}/withdraw/{amt}")
	public double withdrawAccount(@PathVariable String accountId, @PathVariable double amt) {
		return bankService.withdraw(accountId, amt);
	}

	@RequestMapping(value = "/accountId/{accountId}/deposit/{amt}")
	public double depositAccount(@PathVariable String accountId, @PathVariable double amt) {
		return bankService.deposit(accountId, amt);
	}

	@RequestMapping(value = "/accountIdFrom/{accountIdFrom}/accountIdTo/{accountIdTo}/transfer/{amt}")
	public void transferAccountAmount(@PathVariable String accountIdFrom, @PathVariable String accountIdTo, @PathVariable double amt) {
		bankService.transferAccountAmount(accountIdFrom, accountIdTo, amt);
	}


}
