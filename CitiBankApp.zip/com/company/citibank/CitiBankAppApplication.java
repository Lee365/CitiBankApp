package com.company.citibank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CitiBankAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(CitiBankAppApplication.class, args);
	}

}
