package com.company.citibank;

import org.springframework.data.repository.CrudRepository;

import com.company.citibank.model.Account;

public interface CitiBankRepository extends CrudRepository<Account, String> {

}
