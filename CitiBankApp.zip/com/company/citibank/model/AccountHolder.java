package com.company.citibank.model;

import com.company.citibank.CitiBankRepository;

public class AccountHolder {

	private CitiBankRepository bankRepository;

	private Account account1;
	private Account account2;

	public AccountHolder(Account account, CitiBankRepository bankRepository) {
		this.account1 = account;
		this.bankRepository = bankRepository;
	}
	
	public AccountHolder(Account account1, Account account2, CitiBankRepository bankRepository) {
		this.account1 = account1;
		this.account2 = account2;
		this.bankRepository = bankRepository;
	}

	public synchronized void withdraw(double amount) {
		
		if (account1.getBalance() >= amount) {			
			account1.setBalance(account1.getBalance() - amount);
			bankRepository.save(account1);
		} else {
			System.out.println("Account has not got enough balance:" + account1);	
		}
	}

	public synchronized void deposit(double amount) {
		account1.setBalance(account1.getBalance() + amount);
		bankRepository.save(account1);
	}

	public synchronized void transferAccountAmount(double amount) {
		if (account1.getBalance() >= amount) {
			account1.setBalance(account1.getBalance() - amount);
			account2.setBalance(account2.getBalance() + amount);
			bankRepository.save(account1);
			bankRepository.save(account2);
		} else {
			System.out.println("Account has not got enough balance:" + account1);	
		}
	}
	
}