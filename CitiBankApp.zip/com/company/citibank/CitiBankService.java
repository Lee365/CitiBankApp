package com.company.citibank;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.citibank.model.Account;
import com.company.citibank.model.AccountHolder;

@Service
public class CitiBankService {

	@Autowired
	private CitiBankRepository bankRepository;
	
	public void createAccount(Account account) {
		System.out.println("Saving Account:" + account);
		bankRepository.save(account);
	}
	
	public Optional<Account> getAccount(String accountId) {
		System.out.println("Getting Account:" + bankRepository.findById(accountId));
		return bankRepository.findById(accountId);
	}

	public synchronized double withdraw(String accountId, double amount) {
		
		Optional<Account> account1 = bankRepository.findById(accountId);
		AccountHolder accountHolder = new AccountHolder(account1.get(), bankRepository);
		accountHolder.withdraw(amount);
		return account1.get().getBalance();
	}

	public synchronized double deposit(String accountId, double amount) {
		
		System.out.println("Deposit amount:" + amount);
		Optional<Account> account1 = bankRepository.findById(accountId);
		AccountHolder accountHolder = new AccountHolder(account1.get(), bankRepository);
		accountHolder.deposit(amount);
		return account1.get().getBalance();
	}

	public synchronized void transferAccountAmount(String accountIdFrom, String accountIdTo, double amount) {
		
		System.out.println("Deposit amount:" + amount);
		Optional<Account> accountFrom = bankRepository.findById(accountIdFrom);
		Optional<Account> accountTo = bankRepository.findById(accountIdTo);
		AccountHolder accountHolder = new AccountHolder(accountFrom.get(), accountTo.get(), bankRepository);

		accountHolder.transferAccountAmount(amount);
		
	}

}
