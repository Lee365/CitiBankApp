package com.company.citibank;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.company.citibank.model.Account;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CitiBankServiceTests {

	MockMvc mockMvc;
	
	@Autowired
	CitiBankService bankService;
	
	@Test
	public void testCreateAccount() {
		
		Account testAccount = new Account("101", "Adam Pike", 5000.00);
		bankService.createAccount(testAccount);
		Optional<Account> myAccount = bankService.getAccount("101");
		System.out.println("myAccount:" + myAccount);
		assertEquals("101", myAccount.get().getAccountId());
		assertEquals("Adam Pike", myAccount.get().getAccountName());
		assertTrue(myAccount.get().getBalance() == 5000.00);
	}

	@Test
	public void testCreateAccountWithdraw() {
		
		Account testAccount = new Account("101", "Adam Pike", 5000.00);
		bankService.createAccount(testAccount);
		Optional<Account> myAccount = bankService.getAccount("101");
		System.out.println("myAccount:" + myAccount);
		assertEquals("101", myAccount.get().getAccountId());
		assertEquals("Adam Pike", myAccount.get().getAccountName());
		assertTrue(myAccount.get().getBalance() == 5000.00);
		double currentBalance = bankService.withdraw("101", 1000);
		assertTrue(currentBalance == 4000.00);
	}

	@Test
	public void testCreateAccountDeposit() {
		
		Account testAccount = new Account("101", "Adam Pike", 5000.00);
		bankService.createAccount(testAccount);
		Optional<Account> myAccount = bankService.getAccount("101");
		System.out.println("myAccount:" + myAccount);
		assertEquals("101", myAccount.get().getAccountId());
		assertEquals("Adam Pike", myAccount.get().getAccountName());
		assertTrue(myAccount.get().getBalance() == 5000.00);
		double currentBalance = bankService.deposit("101", 1000);
		assertTrue(currentBalance == 6000.00);
	}
	
	@Test
	public void testTransferBetweenAccounts() {
		
		Account testAccountFrom = new Account("101", "Adam Pike", 5000.00);
		bankService.createAccount(testAccountFrom);
		
		Account testAccountTo = new Account("102", "Helen Pike", 10000.00);
		bankService.createAccount(testAccountTo);
		
		bankService.transferAccountAmount(testAccountFrom.getAccountId(), testAccountTo.getAccountId(), 2000);

		Optional<Account> myAccountFrom = bankService.getAccount("101");
		System.out.println("myAccountFrom:" + myAccountFrom);
		assertEquals("101", myAccountFrom.get().getAccountId());
		assertEquals("Adam Pike", myAccountFrom.get().getAccountName());
		assertTrue(myAccountFrom.get().getBalance() == 3000.00);

		Optional<Account> myAccountTo = bankService.getAccount("102");
		System.out.println("myAccountTo:" + myAccountTo);
		assertEquals("102", myAccountTo.get().getAccountId());
		assertEquals("Helen Pike", myAccountTo.get().getAccountName());
		assertTrue(myAccountTo.get().getBalance() == 12000.00);

	}
	
	@Test
	public void testConcurrentWithdrawals() throws InterruptedException {

		Account testAccount = new Account("101", "Adam Pike", 5000.00);
		bankService.createAccount(testAccount);

		Thread t1 = new Thread(() -> {
			for (int i = 1; i < 10; i++) {
				System.out.println("T1 to draw 1000:" + "so far got:" + 1000*(i-1));
				bankService.withdraw("101", 1000);
			}
		});
		
		Thread t2 = new Thread(() -> {
			for (int i = 1; i < 10; i++) {
				System.out.println("T2 to draw 500:" + "so far got:" + 500*(i-1));
				bankService.withdraw("101", 500);
			}		
		});
		
		t1.start();
		try { Thread.sleep(1000);	} catch (Exception e) {}
		t2.start();
		
		t1.join();
		t2.join();
		assertTrue(bankService.getAccount("101").get().getBalance() >= 0);
	}

}